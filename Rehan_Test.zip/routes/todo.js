var express = require('express');
var Todo = require('../models/database');
var router = express.Router();

router.get('/', function(req, res){
    console.log('getting all todo');
    Todo.find({}).exec(function(err, todo){
        if(err) {
            res.send('error has occured');
        } else {
            console.log(todo);
            res.json(todo);
        }
    });
});

router.get('/:id', function(req, res){
    console.log('getting one task');
    Todo.findOne({
        _id: req.params.id
    }).exec(function(err, todo){
        if(err) {
            res.send('error has occured');
        } else {
            console.log(todo);
            res.json(todo);
        }
    });
});

router.post('/', function(req, res){
    var newTodo = new Todo();
    newTodo.title = req.body.title;
    newTodo.description = req.body.description;
    newTodo.save(function(err, todo){
        if(err) {
            res.send('error saving todo');
        } else {
            console.log(todo);
            res.send(todo);
        }
    });
});

router.put('/:id', function(req, res){
    Todo.findOneAndUpdate({
        _id: req.params.id
    },{
        $set: {
            title: req.body.title,
            description: req.body.description,
        }
    },{
        upsert: true
    },function(err, newTodo){
        if(err) {
            res.send('error updating todo');
        } else {
            console.log(newTodo);
            res.send(newTodo);
        }
    });
});

router.delete('/:id', function(req, res){
    Todo.findByIdAndRemove({
        _id: req.params.id
    },function(err, todo){
        if(err) {
            res.send('error deleting todo');
        } else {
            console.log(todo);
            res.send(todo);
        }
    });
});

module.exports = router;